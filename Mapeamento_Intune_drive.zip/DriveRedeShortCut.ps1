#By Otavioj
#Version 1.0
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("C:\Users\Public\Desktop\Mapear Unidade de Rede.lnk")
$Shortcut.TargetPath = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
$Shortcut.Arguments = "-ExecutionPolicy Bypass C:\ProgramData\AutoPilotConfig\DriveMappingScript.ps1 -WindowStyle Hidden"
$Shortcut.IconLocation = "C:\ProgramData\AutoPilotConfig\Icons\DriveRede.ico"
$Shortcut.Save()