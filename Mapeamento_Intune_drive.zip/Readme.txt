Install command
install.cmd
Uninstall command
del /f “C:\Users\Public\Desktop\Mapear Unidade de Rede.lnk”
Install behavior
System
Device restart behavior
No specific action
Return codes
0 Success
1707 Success
3010 Soft reboot
1641 Hard reboot
1618 Retry


Detection rules
Edit
Rules format
Manually configure detection rules
Detection rules
File C:\Users\Public\Desktop\